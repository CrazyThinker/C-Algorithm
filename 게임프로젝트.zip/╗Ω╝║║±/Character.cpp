#include "Character.h"
#include "Turboc.h"

CCharacter::CCharacter(void)
{
	memset(this->Character, 0, sizeof(this->Character));
	memset(this->TextColor, 0, sizeof(this->TextColor));
}

CCharacter::CCharacter(const CCharacter& Character)
{
	this->Character[0] = Character.Character[0], this->Character[1] = Character.Character[1], this->Character[2] = Character.Character[2];
	this->TextColor[0] = Character.TextColor[0], this->TextColor[1] = Character.TextColor[1], this->TextColor[2] = Character.TextColor[2];
}

CCharacter::CCharacter(const char* Character, const char* TextColor)
{
	this->Character[0] = Character[0], this->Character[1] = Character[1], this->Character[2] = '\0';
	this->TextColor[0] = TextColor[0], this->TextColor[1] = TextColor[1], this->TextColor[2] = '\0';
}

CCharacter::~CCharacter(void)
{
}

bool CCharacter::operator == (CCharacter d) const
{
	return this->Character[0] == d.Character[0] && this->Character[1] == d.Character[1] && this->TextColor[0] == d.TextColor[0] && this->TextColor[1] == d.TextColor[1];
}

bool CCharacter::operator != (CCharacter d) const
{
	return this->Character[0] != d.Character[0] || this->Character[1] != d.Character[1] || this->TextColor[0] != d.TextColor[0] || this->TextColor[1] != d.TextColor[1];
}


void CCharacter::PrintScreen(const char* BACKGROUND) const
{
	settextcolor(this->TextColor);
	printf("%s", this->Character);
	if (BACKGROUND) settextcolor(BACKGROUND);
}
