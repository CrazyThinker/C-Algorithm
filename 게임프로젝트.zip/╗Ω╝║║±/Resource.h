#pragma once

#define MAX_WORD 20
#define MAX_WORDLENGTH 15
#define MAX_BASICWORD 1200
#define MAX_LIFE 100
#define MAX_EXP 100
