#pragma once
class CCharacter
{
public:
	char Character[3], TextColor[3];

public:
	CCharacter(void);
	CCharacter(const CCharacter& Character);
	CCharacter(const char* Character, const char* TextColor);
	~CCharacter(void);

	bool operator == (CCharacter d) const;
	bool operator != (CCharacter d) const;

public:
	void PrintScreen(const char* BACKGROUND = nullptr) const;
};
