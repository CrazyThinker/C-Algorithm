#pragma once
#include "Point.h"
#include <list>
using namespace std;

int Initialize(void);
int LoadBasicWords(void);
int Opening(void);
void Help(void);
void Setting(void);
void Game(void);

void GameShowMap(int Type);
void GameShowInputWord(int Type);
void GameShowLife(void);
void GameShowLevel(void);

void GameWordNew(void);
int GameWordDrop(void);
int GameWordClear(void);
